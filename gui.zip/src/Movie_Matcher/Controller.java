package Movie_Matcher;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;

import java.sql.*;
import java.util.*;


public class Controller {
     @FXML private TextArea tags;
     @FXML private ImageView rtImage;
     @FXML private TextField tagSearch, genreSearch, actorSearch, dirSearch, movieSearch, userSearch;
     @FXML private TableView table;
     @FXML private TableRow tableRow;
     @FXML private TabPane tabPane;
     @FXML private Slider slider;
     @FXML private Label sliderLabel, RTimgLabel, IMDBimgLabel;
     @FXML private TableColumn column;

    public static Connection setConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Movie_Matcher?serverTimezone="
                + TimeZone.getDefault().getID(),"root", Main.pass);
        return con;
    }
    @FXML
    private void updateTable(ResultSet rs)throws SQLException {
        table.getColumns().clear();
        table.getItems().clear();
        ObservableList<ObservableList> data = FXCollections.observableArrayList();
        for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
            final int j = i;
            column = new TableColumn(rs.getMetaData().getColumnName(i + 1));
            column.setCellValueFactory((Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param ->
                    new SimpleStringProperty(param.getValue().get(j).toString()));
            table.getColumns().add(column);
        }

        while (rs.next()) {
            //Iterate Row
            ObservableList<String> row = FXCollections.observableArrayList();
            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                //Iterate Column
                row.add(rs.getString(i));
            }
            data.add(row);

        }
        table.setItems(data);
    }
     @FXML
     protected void test(MouseEvent event){
         if(event.getClickCount() > 1) {
             tabPane.getSelectionModel().select(1);
             rtImage.setImage(new Image("https://ia.media-imdb.com/images/M/MV5BMTY5NTU3NDgxNV5BMl5BanBnXkFtZTcwMTI4NzEzMQ@@._V1._SY314_CR2,0,214,314_.jpg"));
             IMDBimgLabel.setVisible(false);
         }
         tags.setText("hey fag");
     }

    @FXML protected void topActors(ActionEvent event) throws SQLException, ClassNotFoundException{
        Connection con = setConnection();
        Statement selectAct = con.createStatement();
        String sql = "SELECT * FROM movie_matcher.movie_actor WHERE ranking < 10 group by movieId order by ranking ASC" +
                " LIMIT " + parseTop((int) slider.getValue());
        ResultSet rs = selectAct.executeQuery(sql);
        updateTable(rs);
        selectAct.close();

    }
    @FXML protected void  topMovies(ActionEvent event) throws SQLException, ClassNotFoundException{
        Connection con = setConnection();
        Statement selectAct = con.createStatement();
        String sql = "SELECT id, title, year, rtAllCriticsNumReviews, rtAllCriticsScore FROM movie_matcher.movie" +
                " group by title" +
                " order by rtAllCriticsScore DESC, rtAllCriticsNumReviews DESC" +
                " LIMIT " + parseTop((int) slider.getValue());
        ResultSet rs = selectAct.executeQuery(sql);
        updateTable(rs);
        selectAct.close();
    }
    @FXML protected void  genreSearchQuery(ActionEvent event) throws SQLException, ClassNotFoundException{
        Connection con = setConnection();
        String sql = "SELECT title,year, rtAllCriticsScore,rtAudienceScore,rtPictureURL,IMDbPictureURL " +
        "FROM movie_matcher.movie " +
        "INNER JOIN movie_matcher.movie_genre " +
        "ON movie.id = movie_genre.movieID " +
        "WHERE movie_genre.genre = ?"+
        " GROUP BY movie.title " +
        "ORDER BY rtAllCriticsScore DESC, rtAllCriticsNumReviews DESC " +
        "LIMIT ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, genreSearch.getText());
        ps.setInt(2, parseTop((int) slider.getValue()));
        ResultSet rs = ps.executeQuery();
        updateTable(rs);
        ps.close();
    }
    @FXML protected void  actorQuery(ActionEvent event) throws SQLException, ClassNotFoundException{
        Connection con = setConnection();
        String sql = "SELECT actorName, movie.title,year,rtAudienceScore,rtPictureURL,IMDbPictureURL " +
        "FROM movie_actor " +
        "INNER JOIN movie " +
        "ON movie.id = movie_actor.movieId "+
        "WHERE actorName LIKE ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, "%" +actorSearch.getText()+ "%");
        ResultSet rs = ps.executeQuery();
        updateTable(rs);
        ps.close();
    }
    @FXML protected void  dirQuery(ActionEvent event) throws SQLException, ClassNotFoundException{
        Connection con = setConnection();
        String sql = "SELECT directorName, movie.title,year,rtAudienceScore,rtPictureURL,IMDbPictureURL " +
                "FROM movie_director " +
                "INNER JOIN movie " +
                "ON movie.id = movie_director.movieId " +
                "WHERE directorName LIKE ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, "%" +dirSearch.getText() +"%");
        ResultSet rs = ps.executeQuery();
        updateTable(rs);
        ps.close();
    }
    @FXML protected void  movieQuery(ActionEvent event) throws SQLException, ClassNotFoundException{
        Connection con = setConnection();
        String sql = "SELECT  movie.title,year,rtAudienceScore,rtPictureURL,IMDbPictureURL " +
                "FROM movie " +
                "WHERE title LIKE ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, "%" +movieSearch.getText()+"%");
        ResultSet rs = ps.executeQuery();
        updateTable(rs);
        ps.close();
    }
    @FXML protected void  tagQuery(ActionEvent event) throws SQLException, ClassNotFoundException{
        Connection con = setConnection();
        String sql = "SELECT movie_tag_list.tag, movie.title,year,rtAudienceScore,rtPictureURL,IMDbPictureURL " +
                "FROM movie " +
                "INNER JOIN movie_tag " +
                "ON movie.id = movie_tag.movieId " +
                "INNER JOIN movie_tag_list " +
                "ON movie_tag.tagId = movie_tag_list.id " +
                "WHERE tag LIKE ? " +
                "order by rtAllCriticsScore";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1,"%" + tagSearch.getText() +"%");
        ResultSet rs = ps.executeQuery();
        updateTable(rs);
        ps.close();
    }
    @FXML protected void sliderNum(MouseEvent event){
        sliderLabel.setText(String.valueOf((int)slider.getValue()));
    }

    private int parseTop(int value) {
        return value;
    }
}
