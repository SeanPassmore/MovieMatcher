Make sure you have JDK 7, 8, 9, or 10 or have JavaFX support

and you have the MySQL .jar file in this directory (mysql-connector-java-8.0.16.jar)
C:\Program Files\Java\JAVA VERSION YOU ARE USING\lib\ext



run the commands:

cd /extracted/folder/location
javac PickerRunner.java Main.java Controller.java
java Main