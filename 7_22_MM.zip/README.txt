To use the GUI through the terminal you need to follow these steps:

1. Install the JDK of Java 7-10 because they have JavaaFX pre-installed

2. Press WIN KEY + R and run the command: `rundll32.exe sysdm.cpl,EditEnvironmentVariables`

3.Under System Variables find the PATH variable and click edit

4. Click Browse on the left hand column and browse to the JDK's bin folder and hit ok C:\Program Files\Java\jdk1.8.0_211\bin was where mine was

5. Unzip the attached file and copy the .jar inside and paste it in the lib\ext folder for your JRE C:\Program Files\Java\jre1.8.0_211\lib\ext was the location of mine

6. Open your terminal and run these commands to run the GUI
```bash
cd path\to\java\files
(EX. cd D:\Pictures\Movie_Matcher (this was where mine was located))
javac PickerRunner.java Main.java Controller.java
java Main
```